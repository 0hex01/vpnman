#!/bin/bash
# Verify OpenVPN installation and configuration

check_openvpn_installed() {
    if ! command -v openvpn &> /dev/null; then
        echo "ERROR: OpenVPN is not installed!"
        return 1
    fi
    
    OPENVPN_VER=$(openvpn --version 2>/dev/null | head -n 1 | awk '{print $2}')
    if [ -z "$OPENVPN_VER" ]; then
        echo "ERROR: Could not determine OpenVPN version!"
        return 1
    fi
    
    echo "OpenVPN version $OPENVPN_VER is installed."
    return 0
}

check_openvpn_service() {
    if ! systemctl is-active --quiet openvpn; then
        echo "WARNING: OpenVPN service is not running. Starting it now..."
        systemctl start openvpn || {
            echo "ERROR: Failed to start OpenVPN service!"
            return 1
        }
    fi
    
    if ! systemctl is-enabled --quiet openvpn; then
        echo "Enabling OpenVPN service to start on boot..."
        systemctl enable openvpn || {
            echo "WARNING: Failed to enable OpenVPN service!"
            return 1
        }
    fi
    
    echo "OpenVPN service is active and enabled."
    return 0
}

# Main execution
echo "=== OpenVPN Verification ==="

check_openvpn_installed || exit 1
check_openvpn_service || exit 1

echo "OpenVPN is properly configured and running."
exit 0
