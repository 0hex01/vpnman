#!/usr/bin/env python3
# VPN Manager - A modern VPN management application
# Created by 0hex01 (0hex01@primarymail.org)
# Copyright (c) 2025 0hex01. All rights reserved.
#
# A dark-themed VPN management application with features including:
# - Easy connection to VPN servers
# - Server speed testing
# - Auto-switching capability
# - Secure credential management
# - Beautiful dark theme interface

import os
import sys

# Set up vendored environment
VENDOR_DIR = '/usr/share/0hex01/vpnmanager/vendor'
VENDOR_BIN = os.path.join(VENDOR_DIR, 'bin')

# Add vendor directories to PATH
os.environ['PATH'] = f"{VENDOR_BIN}:{os.environ.get('PATH', '')}"
os.environ['PYTHONPATH'] = f"{VENDOR_DIR}:{os.environ.get('PYTHONPATH', '')}"

# Add vendor directory to Python path
if os.path.exists(VENDOR_DIR) and VENDOR_DIR not in sys.path:
    sys.path.insert(0, VENDOR_DIR)

# Check if running as root
if os.geteuid() != 0:
    print('This script must be run as root (using pkexec)')
    sys.exit(1)

# Vendorized imports
try:
    # Try to use system GI if available
    try:
        import gi
        gi.require_version('Gtk', '3.0')
        from gi.repository import Gtk, Gdk, GLib
    except (ImportError, ValueError):
        # Fall back to vendored GI if available
        gi_path = os.path.join(VENDOR_DIR, 'gi')
        if os.path.exists(gi_path):
            sys.path.insert(0, os.path.dirname(gi_path))
            import gi
            gi.require_version('Gtk', '3.0')
            from gi.repository import Gtk, Gdk, GLib
        else:
            raise

except ImportError as e:
    print(f"Error: Required GTK3 bindings not found: {e}")
    print("Please ensure python3-gi and gir1.2-gtk-3.0 are installed")
    sys.exit(1)

# Handle display environment for pkexec
if 'PKEXEC_UID' in os.environ:
    user_id = int(os.environ['PKEXEC_UID'])
    try:
        import pwd
        pw_record = pwd.getpwuid(user_id)
        # Set display
        os.environ['DISPLAY'] = ':0'
        # Set user's Xauthority
        os.environ['XAUTHORITY'] = os.path.join(pw_record.pw_dir, '.Xauthority')
        # Set HOME for proper config loading
        os.environ['HOME'] = pw_record.pw_dir
    except Exception as e:
        print(f'Error setting up display environment: {e}')
        sys.exit(1)

# Fork to background if not already forked
'''
if os.environ.get('VPNMAN_FORKED') != '1':
    # Set environment variable to prevent recursive forking
    os.environ['VPNMAN_FORKED'] = '1'
    
    # Fork the process
    pid = os.fork()
    if pid > 0:
        # Parent process exits
        sys.exit(0)
    
    # Child process continues
    # Detach from terminal
    os.setsid()
    
    # Close file descriptors
    os.close(0)
    os.close(1)
    os.close(2)
    
    # Reopen file descriptors to /dev/null
    os.open('/dev/null', os.O_RDWR)
    os.dup2(0, 1)
    os.dup2(0, 2)
'''
import json
import random
import getpass
import subprocess
import tarfile
import tempfile
from pathlib import Path
import re
import time
import threading
from concurrent.futures import ThreadPoolExecutor, as_completed
import tkinter as tk
from tkinter import ttk, messagebox

class VPNManager:
    def __init__(self):
        self.base_dir = Path('/usr/share/0hex01/vpnmanager')
        self.data_dir = Path.home() / '.vpnman'
        self.data_dir.mkdir(exist_ok=True)
        self.credentials_file = self.data_dir / 'credentials.json'
        self.current_process = None
        self.current_config = None
        self.switch_timer = None
        self.auto_switch = False
        self.last_configs = set()  # Track recently used configs
        
        # Config directories
        self.tcp_dir = self.base_dir / 'tcp_configs'
        self.udp_dir = self.base_dir / 'udp_configs'
        self.secure_tcp_dir = self.base_dir / 'secure_tcp_configs'
        self.secure_udp_dir = self.base_dir / 'secure_udp_configs'

        # Create main window with class hint
        self.root = tk.Tk(className='vpnman')
        self.root.title('VPN Manager')
        self.root.geometry('400x600')
        
        # Set window title
        self.root.title('VPN Manager')
        
        # Set window icon
        icon_path = None
        for size in ['128x128', '64x64', '48x48', '32x32']:
            path = f'/usr/share/icons/hicolor/{size}/apps/vpnman.png'
            if os.path.exists(path):
                icon_path = path
                break
                
        if icon_path:
            try:
                # Try setting icon using iconphoto
                icon = tk.PhotoImage(file=icon_path)
                self.root.iconphoto(True, icon)
                print(f'Set icon from {icon_path}')
            except Exception as e:
                print(f'Error setting icon: {e}')
        else:
            print('Could not find icon file')
        
        # Set dark theme colors
        self.colors = {
            'bg': '#2e2e2e',
            'fg': '#e0e0e0',
            'button': '#404040',
            'button_active': '#505050',
            'entry': '#363636',
            'select': '#505050'
        }
        
        # Configure root window colors
        self.root.configure(bg=self.colors['bg'])
        
        # Configure ttk styles
        self.style = ttk.Style()
        self.style.configure('TFrame', background=self.colors['bg'])
        self.style.configure('TLabel', background=self.colors['bg'], foreground=self.colors['fg'])
        self.style.configure('TButton', background=self.colors['button'], foreground=self.colors['fg'])
        self.style.map('TButton',
            background=[('active', self.colors['button_active'])],
            foreground=[('active', self.colors['fg'])])
        self.style.configure('TEntry', fieldbackground=self.colors['entry'], foreground=self.colors['fg'])
        self.style.configure('Treeview',
            background=self.colors['bg'],
            fieldbackground=self.colors['bg'],
            foreground=self.colors['fg'])
        self.style.map('Treeview',
            background=[('selected', self.colors['select'])],
            foreground=[('selected', self.colors['fg'])])
        
        self.setup_gui()

    def prompt_credentials(self):
        """Show a GUI dialog to get credentials"""
        dialog = tk.Toplevel(self.root)
        dialog.title('VPN Credentials')
        dialog.geometry('300x200')
        dialog.transient(self.root)
        dialog.grab_set()
        dialog.configure(bg=self.colors['bg'])

        ttk.Label(dialog, text='Please enter your VPN credentials:', 
                  padding=10).pack(fill='x')

        # Username frame
        username_frame = ttk.Frame(dialog, padding=5)
        username_frame.pack(fill='x', padx=10)
        ttk.Label(username_frame, text='Username:').pack(side='left')
        username_var = tk.StringVar()
        username_entry = ttk.Entry(username_frame, textvariable=username_var)
        username_entry.pack(side='right', expand=True, fill='x', padx=(5, 0))

        # Password frame
        password_frame = ttk.Frame(dialog, padding=5)
        password_frame.pack(fill='x', padx=10)
        ttk.Label(password_frame, text='Password:').pack(side='left')
        password_var = tk.StringVar()
        password_entry = ttk.Entry(password_frame, textvariable=password_var, show='*')
        password_entry.pack(side='right', expand=True, fill='x', padx=(5, 0))

        result = {'credentials': None}

        def on_submit():
            if not username_var.get() or not password_var.get():
                messagebox.showerror('Error', 'Please enter both username and password')
                return
            result['credentials'] = {
                'username': username_var.get(),
                'password': password_var.get()
            }
            dialog.destroy()

        def on_cancel():
            dialog.destroy()

        # Buttons
        button_frame = ttk.Frame(dialog, padding=10)
        button_frame.pack(fill='x', side='bottom')
        ttk.Button(button_frame, text='Submit', 
                   command=on_submit).pack(side='left', padx=5)
        ttk.Button(button_frame, text='Cancel', 
                   command=on_cancel).pack(side='right', padx=5)

        # Focus username field
        username_entry.focus()

        # Bind Enter key to submit
        def on_enter(event):
            on_submit()
        dialog.bind('<Return>', on_enter)

        # Wait for dialog
        dialog.wait_window()
        return result['credentials']

    def load_credentials(self):
        """Load or prompt for VPN credentials"""
        if self.credentials_file.exists():
            with open(self.credentials_file, 'r') as f:
                return json.load(f)
        
        credentials = self.prompt_credentials()
        if not credentials:
            return None
        
        self.data_dir.mkdir(parents=True, exist_ok=True)
        with open(self.credentials_file, 'w') as f:
            json.dump(credentials, f)
        self.credentials_file.chmod(0o600)
        
        return credentials

    def get_config_types(self):
        """Get available configuration types"""
        return [
            ('TCP', self.tcp_dir),
            ('UDP', self.udp_dir),
            ('Secure TCP', self.secure_tcp_dir),
            ('Secure UDP', self.secure_udp_dir)
        ]

    def get_configs_by_type(self, config_dir):
        """Get all configurations from a specific directory"""
        return list(config_dir.glob('*.ovpn'))

    def ping_server(self, config_file):
        """Ping the VPN server and return the response time"""
        try:
            # Extract server address from config file
            with open(config_file, 'r') as f:
                content = f.read()
                # Look for remote address in config
                match = re.search(r'remote\s+(\S+)\s+\d+', content)
                if not match:
                    return config_file, float('inf')
                server = match.group(1)
            
            # Single ping with 1s timeout
            result = subprocess.run(
                ['ping', '-c', '1', '-W', '1', server],
                capture_output=True,
                text=True
            )
            
            if result.returncode == 0:
                # Extract time from ping output
                match = re.search(r'time=([\d.]+)\s*ms', result.stdout)
                if match:
                    ping_time = float(match.group(1))
                    return config_file, ping_time
            
            return config_file, float('inf')
        except Exception as e:
            return config_file, float('inf')

    def select_fastest_config(self, configs, num_samples=10, avoid_current=False):
        """Select the fastest responding config from a random sample"""
        if not configs:
            return None
            
        # Take a random sample of configs (or all if less than num_samples)
        sample_size = min(num_samples, len(configs))
        available_configs = [c for c in configs if c not in self.last_configs]
        if not available_configs:
            self.last_configs.clear()
            available_configs = configs
        
        sampled_configs = random.sample(available_configs, min(sample_size, len(available_configs)))
        
        print(f"\nTesting {len(sampled_configs)} random servers for best connection...")
        start_time = time.time()
        
        # Test configs in parallel with more workers
        results = []
        with ThreadPoolExecutor(max_workers=10) as executor:
            future_to_config = {
                executor.submit(self.ping_server, config): config 
                for config in sampled_configs
            }
            
            for future in as_completed(future_to_config):
                config, ping_time = future.result()
                if ping_time != float('inf'):
                    results.append((config, ping_time))
                    print(f"Server {config.stem}: {ping_time:.1f}ms")
        
        test_duration = time.time() - start_time
        
        if not results:
            print("No responding servers found.")
            print(f"Test completed in {test_duration:.1f} seconds")
            return None
        
        # Sort results by ping time
        results.sort(key=lambda x: x[1])
        
        # Select the fastest config that isn't currently connected
        selected_config = results[0][0]
        if avoid_current and self.current_config and selected_config == self.current_config and len(results) > 1:
            selected_config = results[1][0]
            print(f"\nSelected second fastest server (avoiding current): {selected_config.stem} ({results[1][1]:.1f}ms)")
        else:
            print(f"\nSelected fastest server: {selected_config.stem} ({results[0][1]:.1f}ms)")
        
        print(f"Test completed in {test_duration:.1f} seconds")
        
        # Add to recently used configs
        self.last_configs.add(selected_config)
        if len(self.last_configs) > 5:  # Keep track of last 5 configs
            self.last_configs.pop()
            
        return selected_config

    def random_config(self, config_type):
        """Get the fastest responding configuration from a random sample"""
        configs = self.get_configs_by_type(config_type)
        return self.select_fastest_config(configs)

    def list_configs(self):
        """List available VPN configuration types"""
        print("\nAvailable VPN configuration types:")
        print("-" * 40)
        
        config_types = self.get_config_types()
        for i, (name, pattern) in enumerate(config_types, 1):
            configs = self.get_configs_by_type(pattern)
            count = len(configs)
            print(f"{i}. {name:<15} ({count} configurations available)")
        
        return config_types

    def show_config_details(self, config_dir):
        """Show detailed list of configurations in a directory"""
        configs = self.get_configs_by_type(config_dir)
        if not configs:
            print("No configurations available in this category.")
            return None

        print("\nAvailable configurations:")
        print("-" * 40)
        for i, config in enumerate(sorted(configs), 1):
            # Try to extract country code from filename
            try:
                # Handle different possible formats:
                # ch-us-01.protonvpn.tcp.ovpn -> US
                # us.protonvpn.tcp.ovpn -> US
                # us-01.ovpn -> US
                parts = config.stem.split('.')
                name_parts = parts[0].split('-')
                if len(name_parts) >= 2 and name_parts[0].lower() == 'ch':
                    country_code = name_parts[1].upper()
                else:
                    country_code = name_parts[0].upper()
            except (IndexError, AttributeError):
                country_code = "??"  # Use ?? for unknown country codes
            
            print(f"{i}. {country_code:<6} - {config.name}")

        while True:
            try:
                choice = input("\nEnter configuration number (or 0 to go back): ")
                if choice == '0':
                    return None
                idx = int(choice) - 1
                if 0 <= idx < len(configs):
                    return sorted(configs)[idx]
                print("Invalid selection. Please try again.")
            except ValueError:
                print("Please enter a number.")
            except KeyboardInterrupt:
                print("\nCancelled.")
                return None

    def get_external_ip(self):
        """Get the current external IP address"""
        try:
            result = subprocess.run(
                ["curl", "--silent", "ipinfo.io"],
                capture_output=True,
                text=True,
                timeout=10
            )
            if result.returncode == 0:
                return result.stdout
            return "Could not determine IP address"
        except Exception as e:
            return f"Error getting IP address: {str(e)}"

    def schedule_switch(self):
        """Schedule the next VPN switch"""
        if self.switch_timer:
            self.switch_timer.cancel()
        
        if not self.auto_switch:
            return
            
        # Random interval between 15 and 60 minutes
        switch_interval = random.randint(15 * 60, 60 * 60)
        minutes = switch_interval // 60
        print(f"\nScheduled next VPN switch in {minutes} minutes")
        
        self.switch_timer = threading.Timer(switch_interval, self.switch_vpn)
        self.switch_timer.daemon = True
        self.switch_timer.start()
    
    def switch_vpn(self):
        """Switch to a new VPN connection"""
        if not self.auto_switch:
            return
            
        print("\nTime to switch VPN connection")
        if self.current_config:
            config_dir = self.current_config.parent
            new_config = self.select_fastest_config(self.get_configs_by_type(config_dir), avoid_current=True)
            if new_config:
                print("Switching to new VPN server...")
                if self.current_process:
                    self.current_process.terminate()
                    self.current_process.wait()
                self.connect_vpn(new_config)
            else:
                print("Failed to find a new server, keeping current connection")
                self.schedule_switch()
    
    def connect_vpn(self, config_file):
        """Connect to VPN using selected configuration"""
        credentials = self.load_credentials()
        
        print("\nInitial IP address information:")
        print("-" * 40)
        print(self.get_external_ip())
        print("-" * 40)
        
        # Create temporary auth file
        with tempfile.NamedTemporaryFile(mode='w', delete=False) as auth_file:
            auth_file.write(f"{credentials['username']}\n{credentials['password']}")
            auth_path = auth_file.name
        
        try:
            print(f"\nConnecting to VPN using {config_file.stem}...")
            process = subprocess.Popen(
                ["sudo", "openvpn",
                 "--config", str(config_file),
                 "--auth-user-pass", auth_path,
                 "--auth-nocache"],
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE
            )
            
            # Wait for initial connection attempt
            connected = False
            for _ in range(30):  # Increased wait time for connection
                if process.poll() is not None:
                    # Process ended - there was an error
                    out, err = process.communicate()
                    print("Failed to connect:")
                    print(err.decode())
                    return
                
                # Check process output for successful connection
                output = process.stdout.readline().decode()
                if "Initialization Sequence Completed" in output:
                    connected = True
                    break
                time.sleep(1)
            
            if connected:
                print("VPN connection established!")
                time.sleep(5)  # Wait for connection to stabilize
                print("\nNew IP address information:")
                print("-" * 40)
                print(self.get_external_ip())
                print("-" * 40)
                
                self.current_process = process
                self.current_config = config_file
                
                if self.auto_switch:
                    print("Auto-switching is enabled. Press Ctrl+C to disconnect.")
                    self.schedule_switch()
                else:
                    print("Press Ctrl+C to disconnect.")
                
                try:
                    process.wait()
                except KeyboardInterrupt:
                    print("\nDisconnecting from VPN...")
                    if self.switch_timer:
                        self.switch_timer.cancel()
                    process.terminate()
                    process.wait()
                    self.current_config = None
            else:
                print("Timed out waiting for VPN connection")
                process.terminate()
                process.wait()
                
        finally:
            # Clean up auth file
            os.unlink(auth_path)

    def choose_specific_server(self):
        """Sub-menu for choosing specific server configuration"""
        while True:
            print("\nChoose VPN Type:")
            print("1. TCP")
            print("2. UDP")
            print("3. Secure TCP")
            print("4. Secure UDP")
            print("5. Back to main menu")

            try:
                choice = input("\nEnter your choice (1-5): ")
                if choice == '5':
                    return

                config_dir = None
                if choice == '1':
                    config_dir = self.tcp_dir
                elif choice == '2':
                    config_dir = self.udp_dir
                elif choice == '3':
                    config_dir = self.secure_tcp_dir
                elif choice == '4':
                    config_dir = self.secure_udp_dir
                else:
                    print("Invalid choice. Please try again.")
                    continue

                selected_config = self.show_config_details(config_dir)
                if selected_config:
                    self.connect_vpn(selected_config)
                    return

            except KeyboardInterrupt:
                print("\nReturning to main menu...")
                return

    def setup_gui(self):
        # Status frame
        status_frame = ttk.LabelFrame(self.root, text='Status', padding=10)
        status_frame.pack(fill='x', padx=10, pady=5)
        self.status_label = ttk.Label(self.root, text='Ready', style='TLabel')
        self.status_label.pack(side=tk.BOTTOM, fill=tk.X, padx=5, pady=5)     # Control buttons
        control_frame = ttk.Frame(self.root, padding=10)
        control_frame.pack(fill='x', padx=10, pady=5)

        ttk.Button(control_frame, text='Connect to Random Server', 
                   command=self.connect_random).pack(fill='x', pady=2)
        ttk.Button(control_frame, text='Connect with Speed Test', 
                   command=self.connect_speed_test).pack(fill='x', pady=2)
        ttk.Button(control_frame, text='Connect to Specific Server', 
                   command=self.connect_specific).pack(fill='x', pady=2)
        ttk.Button(control_frame, text='Disconnect', 
                   command=self.disconnect_vpn).pack(fill='x', pady=2)

        # Terminal output
        terminal_frame = ttk.LabelFrame(self.root, text='Terminal Output', padding=10)
        terminal_frame.pack(fill='both', expand=True, padx=10, pady=5)

        # Add scrollbar
        scrollbar = ttk.Scrollbar(terminal_frame)
        scrollbar.pack(side='right', fill='y')

        # Add text widget with dark theme
        self.terminal = tk.Text(terminal_frame, height=10, 
                               bg='black', fg='white',
                               font=('Courier', 10),
                               yscrollcommand=scrollbar.set)
        self.terminal.pack(fill='both', expand=True)
        scrollbar.config(command=self.terminal.yview)

        # Auto-switch frame
        auto_switch_frame = ttk.LabelFrame(self.root, text='Auto Switch', padding=10)
        auto_switch_frame.pack(fill='x', padx=10, pady=5)
        self.auto_switch_var = tk.BooleanVar(value=False)
        ttk.Checkbutton(auto_switch_frame, text='Enable Auto Switch', 
                        variable=self.auto_switch_var, 
                        command=self.toggle_auto_switch).pack()

        # Settings frame
        settings_frame = ttk.LabelFrame(self.root, text='Settings', padding=10)
        settings_frame.pack(fill='x', padx=10, pady=5)
        ttk.Button(settings_frame, text='Reset Credentials', 
                   command=self.reset_credentials).pack(fill='x')

        # Configure terminal
        self.terminal.config(state='disabled')
        self.log_to_terminal('VPN Manager started\n')

    def log_to_terminal(self, message):
        """Add message to terminal widget"""
        self.terminal.config(state='normal')
        self.terminal.insert('end', message)
        self.terminal.see('end')
        self.terminal.config(state='disabled')

    def start_output_threads(self, process):
        """Start threads to read process output"""
        def read_output(pipe, is_error=False):
            prefix = 'ERROR: ' if is_error else ''
            for line in pipe:
                self.log_to_terminal(f'{prefix}{line}')
            pipe.close()

        threading.Thread(target=read_output, args=(process.stdout,), daemon=True).start()
        threading.Thread(target=read_output, args=(process.stderr, True), daemon=True).start()

    def update_status(self, message):
        if hasattr(self, 'status_label'):
            self.status_label.config(text=message)
        self.log_to_terminal(f'Status: {message}\n')

    def run(self):
        self.root.mainloop()

    def connect_speed_test(self):
        try:
            dialog = tk.Toplevel(self.root)
            dialog.title('Speed Test Connection')
            dialog.geometry('300x200')
            dialog.transient(self.root)
            dialog.grab_set()
            dialog.configure(bg=self.colors['bg'])

            # Get config types
            config_types = self.get_config_types()
            if not config_types:
                messagebox.showerror('Error', 'No VPN configurations found')
                dialog.destroy()
                return

            # Create main frame
            main_frame = ttk.LabelFrame(dialog, text='Select VPN Type', padding=10)
            main_frame.pack(fill='both', expand=True, padx=10, pady=5)

            # VPN type selection
            type_var = tk.StringVar()
            type_var.set(config_types[0][0])
            for config_type, _ in config_types:
                ttk.Radiobutton(main_frame, text=config_type, 
                               variable=type_var, value=config_type).pack(anchor='w', pady=2)

            def start_speed_test():
                try:
                    selected_type = type_var.get()
                    for config_type, path in config_types:
                        if config_type == selected_type:
                            config = self.random_config(path)
                            if config:
                                self.connect_vpn(config)
                                dialog.destroy()
                                return
                    messagebox.showerror('Error', 'No valid configuration found for selected type')
                except Exception as e:
                    messagebox.showerror('Error', f'Failed to connect: {str(e)}')
                    self.update_status(f'Error: {str(e)}')

            # Button frame
            button_frame = ttk.Frame(dialog, padding=10)
            button_frame.pack(fill='x')

            ttk.Button(button_frame, text='Start Speed Test', 
                       command=start_speed_test).pack(side='left', padx=5)
            ttk.Button(button_frame, text='Cancel', 
                       command=dialog.destroy).pack(side='right', padx=5)

        except Exception as e:
            messagebox.showerror('Error', f'Failed to open speed test dialog: {str(e)}')
            self.update_status(f'Error: {str(e)}')

    def connect_random(self):
        try:
            config_types = self.list_configs()
            if not config_types:
                messagebox.showerror('Error', 'No VPN configurations found')
                return
            
            _, pattern = random.choice(config_types)
            config = self.random_config(pattern)
            if config:
                self.connect_vpn(config)
            else:
                messagebox.showerror('Error', 'Failed to find a valid configuration')
        except Exception as e:
            messagebox.showerror('Error', f'Failed to connect: {str(e)}')
            self.update_status(f'Error: {str(e)}')

    def connect_specific(self):
        try:
            dialog = tk.Toplevel(self.root)
            dialog.title('Connect to Server')
            dialog.geometry('400x300')
            dialog.transient(self.root)
            dialog.grab_set()
            dialog.configure(bg=self.colors['bg'])

            # Get config types
            config_types = self.get_config_types()
            if not config_types:
                messagebox.showerror('Error', 'No VPN configurations found')
                dialog.destroy()
                return

            # Create frames
            type_frame = ttk.LabelFrame(dialog, text='VPN Type', padding=10)
            type_frame.pack(fill='x', padx=10, pady=5)

            server_frame = ttk.LabelFrame(dialog, text='Available Servers', padding=10)
            server_frame.pack(fill='both', expand=True, padx=10, pady=5)

            # VPN type selection
            type_var = tk.StringVar()
            type_var.set(config_types[0][0])
            for config_type, _ in config_types:
                ttk.Radiobutton(type_frame, text=config_type, 
                               variable=type_var, value=config_type,
                               command=lambda: update_servers()).pack(anchor='w')

            # Server list
            server_list = ttk.Treeview(server_frame, selectmode='browse')
            server_list.pack(fill='both', expand=True)

            def update_servers(*args):
                server_list.delete(*server_list.get_children())
                selected_type = type_var.get()
                configs = []
                for config_type, path in config_types:
                    if config_type == selected_type:
                        configs = sorted(self.get_configs_by_type(path))
                        break
                for i, config in enumerate(configs, 1):
                    server_list.insert('', 'end', text=config)

            def on_select(event):
                try:
                    selection = server_list.selection()
                    if not selection:
                        return
                    
                    item = server_list.item(selection[0])
                    server_name = item['text']
                    
                    # Show confirmation dialog
                    if messagebox.askyesno('Confirm Connection',
                                          f'Do you want to connect to {server_name}?',
                                          icon='question'):
                        config_path = self.get_config_path(type_var.get(), server_name)
                        if config_path and config_path.exists():
                            self.connect_vpn(str(config_path))
                            dialog.destroy()
                        else:
                            messagebox.showerror('Error', 'Selected configuration file not found')
                except Exception as e:
                    messagebox.showerror('Error', f'Failed to connect: {str(e)}')
                    self.update_status(f'Error: {str(e)}')

            # Bind selection event
            server_list.bind('<<TreeviewSelect>>', on_select)

            button_frame = ttk.Frame(dialog, padding=10)
            button_frame.pack(fill='x')
            ttk.Button(button_frame, text='Close', 
                       command=dialog.destroy).pack(side='right', padx=5)

            # Initial server list update
            update_servers()

        except Exception as e:
            messagebox.showerror('Error', f'Failed to open server selection: {str(e)}')
            self.update_status(f'Error: {str(e)}')

    def get_config_path(self, config_type, server_name=None):
        for t, path in self.get_config_types():
            if t == config_type:
                if server_name:
                    return path / server_name
                return path

    def toggle_auto_switch(self):
        self.auto_switch = self.auto_switch_var.get()
        if self.auto_switch:
            self.update_status('Auto-switch enabled')
            self.schedule_switch()
        else:
            self.update_status('Auto-switch disabled')
            if self.switch_timer:
                self.switch_timer.cancel()

    def disconnect_vpn(self):
        if self.current_process:
            self.current_process.terminate()
            self.current_process.wait()
            self.current_config = None
            self.update_status('Disconnected')

    def reset_credentials(self):
        try:
            if self.credentials_file.exists():
                self.credentials_file.unlink()
            self.update_status('Credentials reset')
            messagebox.showinfo('Success', 'Credentials have been reset. You will be prompted for new credentials on the next connection.')
        except Exception as e:
            messagebox.showerror('Error', f'Failed to reset credentials: {str(e)}')
            self.update_status(f'Error: {str(e)}')

    def connect_vpn(self, config_path):
        try:
            if self.current_process:
                self.current_process.terminate()
                self.current_process.wait()

            credentials = self.load_credentials()
            if not credentials:
                self.update_status('Failed to load credentials')
                return

            # Ensure data directory exists
            self.data_dir.mkdir(parents=True, exist_ok=True)

            auth_file = self.data_dir / 'auth.txt'
            try:
                with open(auth_file, 'w') as f:
                    f.write(f"{credentials['username']}\n{credentials['password']}")
            except Exception as e:
                self.update_status(f'Failed to write auth file: {str(e)}')
                return

            cmd = ['sudo', 'openvpn', '--config', str(config_path), '--auth-user-pass', str(auth_file)]
            self.log_to_terminal(f'Running command: {" ".join(cmd)}\n')
            
            # Create pipes for stdout and stderr
            process = subprocess.Popen(
                cmd,
                stdout=subprocess.PIPE,
                stderr=subprocess.PIPE,
                universal_newlines=True,
                bufsize=1
            )
            
            # Start threads to read output
            self.start_output_threads(process)
            
            self.current_process = process
            self.current_config = config_path
            self.update_status(f'Connected to: {Path(config_path).name}')

            if self.auto_switch:
                self.schedule_switch()

        except Exception as e:
            self.update_status(f'Connection error: {str(e)}')
            messagebox.showerror('Connection Error', str(e))

if __name__ == '__main__':
    vpn_manager = VPNManager()
    vpn_manager.run()
