#!/bin/bash

# Enable X11 access for root
xhost +SI:localuser:root > /dev/null 2>&1

# Run vpnman with display access
pkexec env DISPLAY=$DISPLAY XAUTHORITY=$XAUTHORITY /usr/bin/0hex01/vpnman

# Clean up X11 access
xhost -SI:localuser:root > /dev/null 2>&1
